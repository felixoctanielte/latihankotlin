package apk1.apk11

fun main(){
    print("hello")
}